from bs4 import BeautifulSoup
import requests
from nltk.tokenize import word_tokenize, sent_tokenize, RegexpTokenizer
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

lemmatizer = WordNetLemmatizer()
tokenizer = RegexpTokenizer(r'\w+')

def calculate_similarity(user_input, webpage_content):

    # Tokenize and lemmatize user input
    user_tokens = [lemmatizer.lemmatize(token) for token in tokenizer.tokenize(user_input)]
    webpage_tokens = [lemmatizer.lemmatize(token) for token in tokenizer.tokenize(webpage_content)]
    
    # Tokenize and lemmatize webpage content
    user_lemmatized = ' '.join(user_tokens)
    webpage_lemmatized = ' '.join(webpage_tokens)
    
    # Print tokenized and lemmatized words for user input and webpage content
    print()
    print()
    print("User Input:")
    print("  - Tokenized Words:", user_tokens)
    print()
    print("  - Lemmatized Words:", user_lemmatized)
    print()
    print("Webpage Content:")
    print("  - Tokenized Words:", webpage_tokens)
    print()
    print("  - Lemmatized Words:", webpage_lemmatized)
    print()
    print("  - Original Document:",webpage_content)


    # Calculate TF-IDF similarity between user input and webpage content
    vectorizer = TfidfVectorizer()

    tfidf_matrix = vectorizer.fit_transform([user_lemmatized, webpage_lemmatized])

    similarity = cosine_similarity(tfidf_matrix[0], tfidf_matrix[1])[0][0]
    
    return similarity

url = "https://en.wikipedia.org/wiki/Cybercrime"

response = requests.get(url)
html_content = response.text
s = BeautifulSoup(html_content, 'html.parser')
content_div = s.find('div', {'id': 'mw-content-text'})

# Extract webpage content by joining all paragraphs
webpage_content = ' '.join([paragraph.text.strip() for paragraph in content_div.find_all('p') if paragraph.text.strip()])


# Prompt user for input
user_input = input("Enter your text: ")

# Split user input into sentences and paragraphs
sentences = sent_tokenize(user_input)
paragraphs = user_input.split("\n\n")

# Calculate similarity scores for each paragraph
similarity_scores = []
for paragraph in paragraphs:
    similarity = calculate_similarity(paragraph, webpage_content)
    similarity_scores.append(similarity)

filename = 'review.txt'
with open(filename, 'w') as file:
    # Write similarity scores to a file
    for i, score in enumerate(similarity_scores):
        file.write(f"Paragraph {i+1} Similarity: {score}\n")

print("Similarity scores:")
for i, score in enumerate(similarity_scores):
    print(f"Paragraph {i+1} Similarity: {score}")

print(f"Similarity scores saved in {filename}")